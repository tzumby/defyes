from defi_protocols.functions.functions import *
from defi_protocols.Convex import Convex

wallet = '0x849D52316331967b6fF1198e5E32A0eB168D039d'
LP_token_address = '0x845838DF265Dcd2c412A1Dc9e959c7d08537f8a2'#cDAI/cUSDC
block = 'latest'
blockchain = ETHEREUM

print(Convex.underlying(wallet, LP_token_address, block, blockchain))

print(last_block(ETHEREUM))