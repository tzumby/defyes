import os
  
# Get the value of
# 'HOME' environment variable
NODE_CHIADO = os.environ['NODE_CHIADO']
  
# Print the value of
# 'HOME' environment variable

# print("CHIADO_RPC:", NODE_CHIADO)
